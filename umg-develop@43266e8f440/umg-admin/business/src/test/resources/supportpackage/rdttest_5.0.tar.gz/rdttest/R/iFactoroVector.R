iFactoroVector <-
function ( inFactor, toNumber = (FALSE))  {
    
    # if caller wants numeric vector then caller needs to ensure all elements are numbers or system will return NA
    
    # iFactoroVector(c(4,8.5,2,5,8))
    # iFactoroVector(c("abc", "def", "ghi"))
    
    strvec <- as.character(inFactor)
    
    if (isTRUE(toNumber)) {
      return (as.numeric(strvec))
      
    }
    else {
     return (strvec)
      
    }
  }
