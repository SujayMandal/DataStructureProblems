performPrimitiveOpBasedOnClass <-
function ( inVal , toAdd = (TRUE))  {
  # toAdd - only for numeric, if true, add 5 else delete 5
  
  # reverse character string
  # add 2 to numeric 
  # toggle boolean
  # exchange real and imaginary parts for complex
  if (is.na(inVal))
    retVal <- NA
  
  else if (class(inVal) == "character")  {
    split <- strsplit(inVal, NULL)[[1]]
    retVal <- paste(rev(split), collapse='')
  }
  else if ((class(inVal) == "numeric") || (class(inVal) == "integer")) {
    if (toAdd){
      retVal <- inVal + 5
    }
    else {
      retVal <-inVal - 5 
    }
  }
  else if (class(inVal) == "logical") {
    if (inVal == (TRUE)){
      retVal <- (FALSE)
    }
    else {
      retVal <- (TRUE)
    }
  }
  else if (class(inVal) == "complex") {
    retVal <- complex(real = Im(inVal), imaginary = Re(inVal))    
  }
  
  return (retVal);
}
