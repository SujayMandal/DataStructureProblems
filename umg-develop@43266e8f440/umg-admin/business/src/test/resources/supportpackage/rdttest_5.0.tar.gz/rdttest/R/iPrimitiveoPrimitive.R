iPrimitiveoPrimitive <-
function (inVal)	{
	# iPrimitiveoPrimitive (10) 
  # iPrimitiveoPrimitive ((TRUE)) 
  # iPrimitiveoPrimitive ("hello") 
  # iPrimitiveoPrimitive (10.3)
  
	y <- performPrimitiveOpBasedOnClass(inVal)
	return (y);
}
