iMatrixoMatrix <-
function ( inMatrix )	{

	#  iMatrixoMatrix(matrix(1:12,nrow=3, ncol=4))
  #  iMatrixoMatrix(matrix(1.5:12.5,nrow=3, ncol=4))
  #  iMatrixoMatrix(matrix(c((TRUE), (TRUE), (TRUE), (TRUE)),nrow=2, ncol=2))
  #  iMatrixoMatrix(matrix(c("john", "jane", "joe", "jill"),nrow=2, ncol=2))
  
  if (is.na(inMatrix))
    rows <- NA
  else {
  
    numRows <- dim(as.matrix(inMatrix))[1]
    numCols <- dim(as.matrix(inMatrix))[2]
    dummyrow <- rep (NA, numRows * numCols)
    
    rows <- matrix (dummyrow, nrow=numRows, ncol= numCols)
   
    for (i in 1:numRows)	{
      for (j in 1:numCols)	{
        rows[i,j] <- performPrimitiveOpBasedOnClass(inMatrix[i,j], (i %% 2 == 0))
      }
  	}
  }
	return (rows)
}
