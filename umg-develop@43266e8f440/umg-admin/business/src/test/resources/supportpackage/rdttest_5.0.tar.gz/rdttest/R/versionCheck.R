versionCheck <-
function (){
    y <- "RDTTest Version 5"
    return (y)
  }
