iDataFrameoDataFrame <-
function ( inDataFrame )  {
#       iDataFrameoDataFrame (data.frame(
#                           colNumeric = c(4,8.5,2.5), 
#                           colInteger = c(1,3,5), 
#                           colString = c("abc", "def", "efg"), 
#                           colBoolean = c((TRUE), (TRUE), (TRUE)),
#                           colComplex = c(complex(real=5,imaginary=7), complex(real=7, imaginary=-4), complex(real=0, imaginary=2)),
#                           colSingleInt = 45,
#                           colSingleNum = 5.6,
#                           colSingleBoolean = (TRUE),
#                           colSingleString = "john",
#                           colSingleComplex = complex(real=4, imaginary=8),
#                           colList = list (listCol1=c(1,2,3), listCol2=c((TRUE),(TRUE), (TRUE))),
#                           matrix(c(1,4,6,8,5,3), nrow=3, ncol=2),
#                           colArray = array (1:6, c(1,3,2)),
#                           row.names = c("row1", "row2", "row3")
#                    ))
         
  
    if (is.na(inDataFrame))
      retList <- NA
    else {
      rownames <- row.names(inDataFrame)
      columnnames <- colnames(inDataFrame)
      
      for (index in 1:length(rownames)){
        rownames[index] <- paste (rownames[index], "-x", sep="")
      }
      
      retList <- data.frame(row.names=rownames)
      
      for (index in 1:length(columnnames)) {
        
        sublist <- inDataFrame[[columnnames[index]]]
        
        
        if (class(sublist) == "matrix") {
          y <- iMatrixoMatrix(sublist)  
          
        } else if (class(sublist) == "array"){
          y <- i3DArrayo3DArray(sublist)  
        }
        else if (class(sublist) == "list"){
          y <- iListoList(sublist)     
        }else if (class(sublist) == "factor"){
          x <- iFactoroVector(sublist)     
          y <- iVectoroVector(x)
        }else {
         
          y <- iVectoroVector(sublist)
        }
        
        retList[columnnames[index]] <- y
        
      }
    } 
    return (retList)
    
  }
