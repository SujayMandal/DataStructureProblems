i2DArrayo2DArray <-
function ( in2DArray )	{

  #  i2DArrayo2DArray(array(1:9, c(3,3)))
  #  i2DArrayo2DArray(array(1.3:9.3, c(3,3)))
  #  i2DArrayo2DArray(array(c((TRUE), (TRUE), (TRUE), (TRUE)), c(2,2)))
  #  i2DArrayo2DArray(array(c("abc", "def", "ghi", "jkl"), c(2,2)))
  
  if (is.na(in2DArray ))
    rows <- NA
  else {
    numRows <- dim(as.array(in2DArray))[1]
    numCols <- dim(as.array(in2DArray))[2]
    
    dummyrows <- rep (NA, numRows*numCols)
  	rows <- array(dummyrows, c(numRows, numCols))
    
  	for (i in 1:numRows)	{
  		for (j in 1:numCols)	{
  			rows[i,j] <- performPrimitiveOpBasedOnClass(in2DArray[i,j])	
  		}
  	}
  }	
	return (rows)
}
