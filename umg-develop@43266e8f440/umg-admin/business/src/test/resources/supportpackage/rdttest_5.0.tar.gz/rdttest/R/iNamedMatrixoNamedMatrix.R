iNamedMatrixoNamedMatrix <-
function ( inNamedMatrix )  {
    # adds 5 to every even row element of 2D array, subtracts 5 from every odd row of 2D array
    # reverses string
    # toggles boolean
    # change name of row and col by appending -x
    
    #  iNamedMatrixoNamedMatrix(matrix(1:12,nrow=3, ncol=4, dimnames=list(c("r1", "r2", "r3"), c("c1", "c2", "c3", "c4"))))
    if (is.na(inNamedMatrix)) {
      rows <- NA
    }
    else {
      numRows <- dim(as.matrix(inNamedMatrix))[1]
      numCols <- dim(as.matrix(inNamedMatrix))[2]
     
      dummyrow <- rep (NA, numRows * numCols)
      rows <- matrix (dummyrow, nrow=numRows, ncol= numCols)
      
      for (i in 1:numRows)	{
        for (j in 1:numCols)	{
          rows[i,j] <- performPrimitiveOpBasedOnClass(inNamedMatrix[i,j], (i %% 2 == 0))	
        }
      }
      
      rowvec <- dimnames(inNamedMatrix)[[1]]
      colvec <- dimnames (inNamedMatrix)[[2]]
      
      for (index in 1:length(rowvec)){
        if (is.na(rowvec[index]))
          rowvec[index] <- NA
        else
          rowvec[index] <- paste(rowvec[index],"x", sep="-")
      }
      for (index in 1:length(colvec)){
        if (is.na(colvec[index]))
          colvec[index] <- NA
        else
          colvec[index] <- paste(colvec[index],"x", sep="-")
      }
      dimnames(rows)[[1]] <- rowvec
      dimnames(rows)[[2]] <- colvec
    } 
    return (rows)
  }
