iVectoroVector <-
function ( inVector )	{
	# iVectoroVector(c(4,8.5,2,5,8))
  # iVectoroVector(c("abc", "def", "ghi", "jkl"))
  # iVectoroVector(c((TRUE), (FALSE), (TRUE), (FALSE)))
  
  if (is.na(inVector))
    y <- NA
  else {
    y <- rep (NA, length(inVector))
    
  	for (i in 1:length(inVector))	{
  
     y[i] <- performPrimitiveOpBasedOnClass(inVector[i], (i %% 2 == 0))
     
      
  	}
  }
  return (y);
}
