iComplexoVector <-
function (inComplex){
    if (is.na(inComplex )){
      y <- NA;
    }
    else {
      a <- Re(inComplex)
      b <- Im(inComplex)
      y <- c(a,b )
    }
    return (y)
  }
