iListoList <-
function ( inList )  {
#           iListoList (list(
#                       c(4,8.5,2,5,8), 
#                       c(1,3,5), 
#                       c("abc", "def", "efg"), 
#                       c((TRUE), (TRUE), (TRUE), (TRUE)),
#                       c(complex(real=5,imaginary=7), complex(real=7, imaginary=-4), complex(real=0, imaginary=2), complex(real=8, imaginary=0)),
#                       named1 = c(5,7,3,5),
#                       named2 = c((TRUE), (TRUE), (TRUE), (TRUE)),
#                       named3 = c("manasi", "seshadri", "altisource", "com"),
#                       45,
#                       5.6,
#                       (TRUE),
#                       "john",
#                       complex(real=4, imaginary=8),
#                       list (c(1,2,3), 6, 7),
#                       matrix(c(1,4,6,8), nrow=2, ncol=2),
#                       array (1:27, c(3,3,3))
#                ))
#   
    if (is.na(inList)){
      retList <- NA
    }
    else {
      retList <- list()
      
     
      
      if (length(names(inList)) > 0)  {
        allNames <- names(inList)
      }else {
        allNames <- rep(NA, length(names(inList)))
      }
      
      for (index in 1:length(inList)) {
        
        sublist <- inList[[index]]
        
        if (class(sublist) == "matrix") {
          y <- iMatrixoMatrix(sublist)  
          
        } else if (class(sublist) == "array"){
          y <- i3DArrayo3DArray(sublist)  
        }
        else if (class(sublist) == "list"){
          #MS: some problem with recursion with sublist names  
          y <- iListoList(sublist)     
          
        }else {
          y <- iVectoroVector(sublist)
        }
        
              
        retList <- append (retList, list (y))
          
      }
      
      names(retList) <- allNames
    }
    return (retList)
    
  }
