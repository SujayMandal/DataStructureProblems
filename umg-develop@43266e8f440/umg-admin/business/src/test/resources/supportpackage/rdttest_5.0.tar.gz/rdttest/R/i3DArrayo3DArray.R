i3DArrayo3DArray <-
function ( in3DArray )  {
    # i3DArrayo3DArray(array(1:24, c(4, 3, 2)))
    # i3DArrayo3DArray(array(1.4:8.4, c(2, 2, 2)))
    # i3DArrayo3DArray(array(c((TRUE),(TRUE),(TRUE),(TRUE),(TRUE),(TRUE),(TRUE),(TRUE) ), c(2, 2, 2)))
    # i3DArrayo3DArray(array(c("abc", "def", "fgh", "ghi", "jkl", "lmn" , "mno", "pqr"), c(2, 2, 2)))
    
    if (is.na(in3DArray ))
      levels <- NA
    else {
      numLevels <- dim(as.array(in3DArray))[1]
      numRows <- dim(as.array(in3DArray))[2]
      numCols <- dim(as.array(in3DArray))[3]
      
      dummyrows <- rep (NA, numRows*numCols*numLevels)
      levels <- array(dummyrows, c(numLevels, numRows, numCols))
      
      for (i in 1:numLevels) {
        for (j in 1:numRows)	 {
          for (k in 1:numCols)	 {
              levels[i, j, k] <- performPrimitiveOpBasedOnClass(in3DArray[i,j,k], (i %% 2 == 0))
          }
        }
      }
    }
    return (levels)
  }
